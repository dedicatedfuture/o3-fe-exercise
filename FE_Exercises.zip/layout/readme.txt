**Instructions**

Fix the layout so both columns fit side-by-side. Retain the existing padding around each column and the existing column percentages.